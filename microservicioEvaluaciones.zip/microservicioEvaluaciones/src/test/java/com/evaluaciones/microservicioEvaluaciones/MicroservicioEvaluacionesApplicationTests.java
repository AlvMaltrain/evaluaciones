package com.evaluaciones.microservicioEvaluaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioEvaluacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
