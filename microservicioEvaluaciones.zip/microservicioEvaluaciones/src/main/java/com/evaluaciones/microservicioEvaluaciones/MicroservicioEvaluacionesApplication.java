package com.evaluaciones.microservicioEvaluaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioEvaluacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioEvaluacionesApplication.class, args);
	}

}
